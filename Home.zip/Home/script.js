// Toggle hamburger menu visibility
function toggleMenu() {
  const navLinks = document.querySelector('.nav-links');
  navLinks.classList.toggle('show');
}

// Handle "Send Request" button click
function sendRequest(button) {
  button.textContent = "Request Sent";
  button.disabled = true;
  alert("Open chat page");
}
